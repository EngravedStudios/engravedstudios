import { Client, Users } from 'node-appwrite';

export default async ({ req, res, log, error }) => {
  // Initialize Appwrite SDK
  const client = new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  const users = new Users(client);

  try {
    // Parse request body
    const payload = JSON.parse(req.body || '{}');
    const userId = payload.userId;

    if (!userId) {
      return res.json({
        success: false,
        error: 'userId is required'
      }, 400);
    }

    log(`Fetching details for user: ${userId}`);

    // Fetch user from Appwrite Users API
    const user = await users.get(userId);

    // Return user details
    return res.json({
      success: true,
      data: {
        id: user.$id,
        name: user.name,
        email: user.email,
        emailVerification: user.emailVerification,
        status: user.status
      }
    });

  } catch (err) {
    error(`Error fetching user: ${err.message}`);
    return res.json({
      success: false,
      error: err.message
    }, 500);
  }
};
