# Appwrite Function: Get User Details

This function fetches user details (name, email, verification status) from a user ID using the Appwrite Server SDK.

## Deployment Instructions

### 1. Using Appwrite Console (Recommended)

1. Go to your Appwrite Console → **Functions**
2. Click **"Create Function"**
3. Configure:
   - **Name**: `get-user-details`
   - **Runtime**: Node.js 18.0 or later
   - **Entry Point**: `src/main.js`
4. Upload the function code:
   - Upload `functions/get-user-details/` directory
5. Set Environment Variables (if not auto-set):
   - `APPWRITE_API_KEY`: Your Appwrite API Key (Server SDK key)
   - Note: `APPWRITE_FUNCTION_API_ENDPOINT` and `APPWRITE_FUNCTION_PROJECT_ID` are auto-set
6. Click **"Create"**

### 2. Using Appwrite CLI

```bash
# Navigate to project root
cd /Users/dohlepascal/Documents/Voit/blog

# Deploy function
appwrite deploy function

# Or create manually
appwrite functions create \
  --functionId get-user-details \
  --name "Get User Details" \
  --runtime node-18.0 \
  --entrypoint "src/main.js"

# Deploy code
appwrite functions createDeployment \
  --functionId get-user-details \
  --code "functions/get-user-details" \
  --activate true
```

### 3. Generate API Key

You need a Server API Key with `users.read` permission:

1. Go to Appwrite Console → **Settings** → **API Keys**
2. Click **"Add API Key"**
3. Configure:
   - **Name**: `server-functions`
   - **Scopes**: Check `users.read`
4. Copy the API Key
5. Add to Function Environment Variables:
   - Key: `APPWRITE_API_KEY`
   - Value: (paste your key)

## Usage from Flutter

```dart
final response = await appwriteService.functions.createExecution(
  functionId: 'get-user-details',
  body: json.encode({'userId': 'USER_ID_HERE'}),
);

final data = json.decode(response.responseBody);
if (data['success']) {
  final userName = data['data']['name'];
  final userEmail = data['data']['email'];
}
```

## Testing

You can test the function directly from Appwrite Console:

1. Go to Functions → get-user-details → **Execute**
2. Body: `{"userId": "YOUR_USER_ID"}`
3. Click **Execute**

Expected response:
```json
{
  "success": true,
  "data": {
    "id": "...",
    "name": "John Doe",
    "email": "john@example.com",
    "emailVerification": true,
    "status": true
  }
}
```
